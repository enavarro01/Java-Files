/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritance;

/**
 *
 * @author Jho
 */
public class InheritanceTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        School sc=new School();

        System.out.println(sc.getStud().eat());
        System.out.println(sc.getStud().sendMoney());
    }

}

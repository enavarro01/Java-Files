/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package simplecalculatorgui;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Jho
 */
public class SimpleCalculatorGUI extends JFrame{

    JLabel lblFirst=new JLabel("First Number : ");
    JLabel lblSecond=new JLabel("Second Number : ");
    JLabel lblResult=new JLabel("Result : ");

    JTextField txtFirst=new JTextField(50);
    JTextField txtSecond=new JTextField(50);

    JButton btnAdd=new JButton("ADD");
    JButton btnSubtract=new JButton("SUBTRACT");
    JButton btnMultiply=new JButton("MULTIPLY");
    JButton btnDivide=new JButton("DIVIDE");

    JPanel pane=new JPanel();

    public SimpleCalculatorGUI(){
        super("Simple Calculator GUI");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(400,300);
        this.setLocation(100,50);
        this.setVisible(true);

        lblFirst.setOpaque(true);
        lblFirst.setSize(120,50);
        lblFirst.setLocation(50,20);

        lblSecond.setOpaque(true);
        lblSecond.setSize(120,20);
        lblSecond.setLocation(50,50);

        lblResult.setOpaque(true);
        lblResult.setSize(120,20);
        lblResult.setLocation(50,80);

        txtFirst.setOpaque(true);
        txtFirst.setSize(100,20);
        txtFirst.setLocation(150,20);

        txtSecond.setOpaque(true);
        txtSecond.setSize(100,20);
        txtSecond.setLocation(150,50);

        btnAdd.setOpaque(true);
        btnAdd.setSize(100,20);
        btnAdd.setLocation(50,120);
        btnAdd.setMnemonic('A');

        btnSubtract.setOpaque(true);
        btnSubtract.setSize(100,20);
        btnSubtract.setLocation(150,120);
        btnSubtract.setMnemonic('S');

        btnMultiply.setOpaque(true);
        btnMultiply.setSize(100,20);
        btnMultiply.setLocation(50,140);
        btnMultiply.setMnemonic('M');

        btnDivide.setOpaque(true);
        btnDivide.setSize(100,20);
        btnDivide.setLocation(150,140);
        btnDivide.setMnemonic('D');
        
        pane.setLayout(null);
        this.setContentPane(pane);

        this.getContentPane().add(lblFirst);
        this.getContentPane().add(lblSecond);
        this.getContentPane().add(lblResult);

        this.getContentPane().add(txtFirst);
        this.getContentPane().add(txtSecond);

        this.getContentPane().add(btnAdd);
        this.getContentPane().add(btnSubtract);
        this.getContentPane().add(btnMultiply);
        this.getContentPane().add(btnDivide);
    }
    public static void main(String[] args) {
        SimpleCalculatorGUI sc=new SimpleCalculatorGUI();          
    }

} //end of class

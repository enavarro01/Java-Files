/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabankphase2ver2;
import java.text.*;

/**
 *
 * @author Jho
 */
public class BankAccount {
    DecimalFormat df=new DecimalFormat("#,##0.00");

    protected int acctNo;
    protected double balance;

    public BankAccount(){
        this.acctNo=0;
        this.balance=0.0;
    }

    public int getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(int acctNo) {
        this.acctNo = acctNo;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    //custom methods
    public void balanceInquiry(){
        System.out.println("\n\tCurrent Balance Php: " + df.format(this.balance));
    }

    public void deposit(double amount){
        double interest;

        if(amount<1){
            System.out.println("\n\tINVALID AMOUNT!");
        }
        else{
            this.balance+=amount;
            interest=this.balance*0.01;
            this.balance+=interest;
            System.out.println("\n\tYour current balance has been updated");
        }
    }

    public void withdraw(double amount){
        if(amount<1){
            System.out.println("\n\tINVALID AMOUNT!");
        }
        else if(amount>this.balance){
            System.out.println("\n\tINSUFFICIENT FUND!");
        }
        else if(this.balance-amount < 10000){
            System.out.println("\n\tTHE MAINTAINING BALANCE IS Php 10,000.00!");
        }
        else{
            this.balance-=amount;
            System.out.println("\n\tYour current balance has been updated");
        }
    }

    public void closeAccount(){
        this.acctNo=0;
        this.balance=0.0;
        System.out.println("\n\tYour account has been closed");
    }

    public boolean validateAcctNo(int acctNo){
        if(this.acctNo==acctNo){
            return true;
        }
        else
            return false;
    }



}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabankphase2;
import java.io.*;
import java.text.*;

/**
 *
 * @author Jho
 */
public class Teller {

//------------------------------------------------------------------------------

    public static void inputClientInfo(Client cl) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        double balance;  int acctNo;
        String name,address,bday;
        long contactNo; int acctType;


        System.out.println("\n\n\n\t\t------NEW ACCOUNT------");
        System.out.print("\n\tClient Name --> ");
        name=br.readLine();
        System.out.print("\tAddress     --> ");
        address=br.readLine();
        System.out.print("\tBirthday    --> ");
        bday=br.readLine();
        System.out.print("\tContact No. --> ");
        contactNo=Long.parseLong(br.readLine());

        cl.setName(name);
        cl.setAddress(address);
        cl.setBday(bday);
        cl.setContactNo(contactNo);
    }

//------------------------------------------------------------------------------

    public static int displayMenu() throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int transact;
        do{
        System.out.print("\n\n\n\t\t------JAVA BANK MAIN MENU------" +
                               "\n\t[1] New Account" +
                               "\n\t[2] Balance Inquiry" +
                               "\n\t[3] Deposit" +
                               "\n\t[4] Withdraw" +
                               "\n\t[5] Client Profile" +
                               "\n\t[6] Close Account" +
                               "\n\t[7] Exit" +
                               "\n\tPlease enter transaction code --> ");
        transact=Integer.parseInt(br.readLine());
        if(transact<1 || transact>7)
            System.out.println("\tINVALID CODE...Please try again!");
        }while(transact<1 || transact>7);

        return transact;
    }
//------------------------------------------------------------------------------

    public static void createNewAcct(Client cl) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        double balance;  int acctNo;

        do{
            System.out.print("\n\tEnter initial savings deposit --> ");
            balance=Double.parseDouble(br.readLine());
            if(balance<5000)
                System.out.print("\n\tMinimum initial deposit is Php 5,000");
        }while(balance<5000);
                cl.getAcct().setBalance(balance);
                acctNo=999+(int)(Math.random()*1000);
                cl.getAcct().setAcctNo(acctNo);
                System.out.println("\n\tYour account number is " + cl.getAcct().getAcctNo());        
    }
//-------------------------THIS IS THE MAIN METHOD------------------------------

    public static void main(String[] args) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        DecimalFormat df=new DecimalFormat("#,##0.00");
        Client cl=new Client();
        int trans,acctNo;
        double amount; char sure;

        do{
        trans=displayMenu();
        switch(trans){
            case 1: // New Account
                if(cl.getAcct().getAcctNo()==0){
                    inputClientInfo(cl);
                    createNewAcct(cl);
                }
                else
                    System.out.print("\n\tNOT AN ALLOWED TRANSACTION! ");
                break;

            case 2: //Balance Inquiry
                if(cl.getAcct().getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------BALANCE INQUIRY------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cl.getAcct().getAcctNo()==acctNo)
                        System.out.println("\n\tCurrent Balance Php: " + df.format(cl.getAcct().getBalance()));
                    else
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");                    
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 3: //Deposit
                if(cl.getAcct().getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------DEPOSIT TRANSACTION------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cl.getAcct().getAcctNo()==acctNo){
                        System.out.print("\n\tEnter the amount to be deposited --> ");
                        amount=Double.parseDouble(br.readLine());
                        cl.getAcct().deposit(amount);
                    }
                    else{
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 4:  //Withdraw
                if(cl.getAcct().getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------WITHDRAW TRANSACTION------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cl.getAcct().getAcctNo()==acctNo){
                        System.out.print("\n\tEnter the amount to be withdrawn --> ");
                        amount=Double.parseDouble(br.readLine());
                        cl.getAcct().withdraw(amount);
                    }
                    else{
                    System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 6: //Close Account
                if(cl.getAcct().getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------CLOSE ACCOUNT TRANSACTION------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cl.getAcct().getAcctNo()==acctNo){
                        System.out.print("\n\tAre you sure to close your account? [y/n] --> ");
                        sure=(char)System.in.read();
                        System.in.read();
                        if(sure=='y' || sure=='Y'){
                            cl.getAcct().setAcctNo(0);
                            cl.getAcct().setBalance(0);
                            System.out.println("\n\tYour account has been closed...");
                        }
                    }
                    else{
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 5: //Client Profile
                if(cl.getAcct().getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------CLIENT PROFILE------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cl.getAcct().getAcctNo()==acctNo){
                        System.out.print(cl.toString());
                    System.out.print("\n\tCurrent Balance : Php "+df.format(cl.getAcct().getBalance()));
                    }
                    else{
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 7: //Exit
                System.out.println("\n\tThank you for banking with us...");
        }
        }while(trans!=7);
    }

}

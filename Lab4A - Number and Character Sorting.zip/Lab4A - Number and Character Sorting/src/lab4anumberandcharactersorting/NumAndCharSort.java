/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab4anumberandcharactersorting;
import java.io.*;

/**
 *
 * @author jtfulgencio
 */
public class NumAndCharSort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int[] intValues=new int[5];
        char chrValues[],tempChar[]={' '},answer;
        String strValue;
        int i,pass=1,temp;
do{
        System.out.println("THIS PROGRAM WILL SORT INTEGERS AND CHARACTERS");
        System.out.println();
        for(i=0;i<intValues.length;i++){
            System.out.print("Enter value for index["+i+"] here --> ");
            intValues[i]=Integer.parseInt(br.readLine());
        }
        System.out.println();
        System.out.print("Enter a string here --> ");
        strValue=br.readLine();

        //convert the string to chracter Array
        chrValues=strValue.toCharArray();

        //sort the integers and display
        while(pass<intValues.length)
        {
            for(i=0;i<(intValues.length-pass);i++)
            {
                if(intValues[i]<intValues[i+1])
                {
                    temp=intValues[i];
                    intValues[i]=intValues[i+1];
                    intValues[i+1]=temp;
                }
            }
            pass++;
        }

        System.out.println();
        System.out.println("The integers after sorting are : ");
        for(i=0;i<intValues.length;i++)
        {
            System.out.println(intValues[i]);
        }

        //sort the characters and display
        pass=1;
        while(pass<chrValues.length)
        {
            for(i=0;i<(chrValues.length-pass);i++)
            {
                if(chrValues[i]<chrValues[i+1])
                {
                    tempChar[0]=chrValues[i];
                    chrValues[i]=chrValues[i+1];
                    chrValues[i+1]=tempChar[0];
                }
            }
            pass++;
        }

        System.out.println();
        System.out.println("The characters after sorting are : ");
        for(i=0;i<chrValues.length;i++)
        {
            System.out.println(chrValues[i]);
        }

        System.out.print("Continue? [y/n] --> ");
        answer=(char)System.in.read();
        System.in.read();

        for(i=1;i<10;i++){
            System.out.println();
        }

}while(answer=='y' || answer=='Y');
    }
}


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javacreditphase1;
import java.io.*;
import java.text.*;

/**
 *
 * @author Jho
 */
public class Client {

    //------------------------------------------------------------------------------

    public static int displayMenu() throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int transact;
        do{
        System.out.print("\n\n\n\t\t------JAVA CREDIT MAIN MENU------" +
                               "\n\t[1] New Credit Account" +
                               "\n\t[2] Credit Balance Inquiry" +
                               "\n\t[3] Purchase" +
                               "\n\t[4] Payment" +
                               "\n\t[5] Close Credit Account" +
                               "\n\t[6] Exit" +
                               "\n\tPlease enter transaction code --> ");
        transact=Integer.parseInt(br.readLine());
        if(transact<1 || transact>6)
            System.out.println("\tINVALID CODE...Please try again!");
        }while(transact<1 || transact>6);

        return transact;
    }
//------------------------------------------------------------------------------

    public static double createNewAcct(Credit cd) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        DecimalFormat df=new DecimalFormat("#,##0.00");
        double income,fixedCreditLimit=0.0;  int acctNo;

        System.out.print("\n\n\t\t------NEW CREDIT ACCOUNT------");
        do{
        System.out.print("\n\tEnter your annual income --> ");
        income=Double.parseDouble(br.readLine());
        if(income>=200000 && income<300000)
            fixedCreditLimit=30000;
        else if(income>=300000 & income<=500000)
            fixedCreditLimit=50000;
        else if(income>500000)
            fixedCreditLimit=100000;
        else
            System.out.println("\tINVALID INCOME!");
        }while(income<200000);

        cd.setCreditLimit(fixedCreditLimit);
        acctNo=999+(int)(Math.random()*1000);
        cd.setCreditAcctNo(acctNo);
        System.out.println("\tYour credit limit is Php " + df.format(cd.getCreditLimit()));
        System.out.println("\tYour account number is " + cd.getCreditAcctNo());

        return fixedCreditLimit;
    }
     
     
//-------------------------THIS IS THE MAIN METHOD------------------------------

    public static void main(String[] args) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        Credit cd=new Credit();
        int trans,acctNo;
        double amount,fixedCreditLimit=0.0; char sure;

        do{
        trans=displayMenu();
        switch(trans){
            case 1: // New Credit Account
                if(cd.getCreditAcctNo()==0)
                    fixedCreditLimit=createNewAcct(cd);
                else
                    System.out.print("\n\tNOT AN ALLOWED TRANSACTION! ");
                break;

            case 2: //Credit Balance Inquiry
                if(cd.getCreditAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------CREDIT BALANCE INQUIRY------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cd.validateAcctNo(acctNo))
                        cd.inquireCreditBalance();
                    else
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 3: //Purchase
                if(cd.getCreditAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------PURCHASE TRANSACTION------");
                    System.out.print("\n\n\tEnter your credit account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cd.validateAcctNo(acctNo)){
                        System.out.print("\n\tEnter the amount of purchase --> ");
                        amount=Double.parseDouble(br.readLine());
                        fixedCreditLimit=cd.purchase(amount,fixedCreditLimit);
                    }
                    else{
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 4:  //Withdraw
                if(cd.getCreditAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------PAYMENT TRANSACTION------");
                    System.out.print("\n\n\tEnter your credit account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cd.validateAcctNo(acctNo)){
                        System.out.print("\n\tEnter the amount of payment --> ");
                        amount=Double.parseDouble(br.readLine());
                        cd.payCredit(amount,fixedCreditLimit);
                    }
                    else{
                    System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 5: //Close Credit Account
                if(cd.getCreditAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------CLOSE CREDIT ACCOUNT TRANSACTION------");
                    System.out.print("\n\n\tEnter your credit account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(cd.validateAcctNo(acctNo)){
                        System.out.print("\n\tAre you sure to close your credit account? [y/n] --> ");
                        sure=(char)System.in.read();
                        System.in.read();
                        if(sure=='y' || sure=='Y'){
                            cd.closeAccount();
                        }
                    }
                    else{
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;  
            
            case 6: //Exit
                System.out.println("\n\tWe are pleased to have served you...");
        }
        }while(trans!=6);
    }


}

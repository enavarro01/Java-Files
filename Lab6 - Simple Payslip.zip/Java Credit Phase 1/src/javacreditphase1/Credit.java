/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javacreditphase1;
import java.text.*;

/**
 *
 * @author Jho
 */
public class Credit {
    DecimalFormat df=new DecimalFormat("#,##0.00");

    private int creditAcctNo;
    private double creditBalance;
    private double creditLimit;

    public Credit(){
        this.creditAcctNo=0;
        this.creditBalance=0.0;
        this.creditLimit=0.0;
    }

    public int getCreditAcctNo() {
        return creditAcctNo;
    }

    public void setCreditAcctNo(int creditAcctNo) {
        this.creditAcctNo = creditAcctNo;
    }

    public double getCreditBalance() {
        return creditBalance;
    }

    public void setCreditBalance(double creditBalance) {
        this.creditBalance = creditBalance;
    }

    public double getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(double creditLimit) {
        this.creditLimit = creditLimit;
    }

    //custom methods
    public void inquireCreditBalance(){
        System.out.println("\n\tCredit Limit   : Php " + df.format(this.creditLimit));
        System.out.println("\n\tCredit Balance : Php " + df.format(this.creditBalance));
    }

    public double purchase(double amount,double fixedCreditLimit){
        double interest;

        if(amount<1 || amount>this.creditLimit)
            System.out.println("\n\tINVALID AMOUNT!");
	else if( ((this.creditBalance+amount)*(1.03)) > fixedCreditLimit)
            System.out.println("\n\tYou will exceed your credit limit! This is not alowed!");
	else{
            this.creditBalance+=amount;
            interest=this.creditBalance*0.03;
            this.creditBalance+=interest;
            this.creditLimit=fixedCreditLimit-this.creditBalance;
            System.out.println("\n\tYour credit balance has been updated!");
	}
        return fixedCreditLimit;
    }

    public void payCredit(double amount,double fixedCreditLimit){
        if(amount<1)
            System.out.println("\n\tINVALID AMOUNT!");
	else if(amount>this.creditBalance)
            System.out.println("\n\tYou are paying more than your credit balance!");
	else{
            this.creditBalance-=amount;
            this.creditLimit+=amount;
            this.creditLimit=fixedCreditLimit-this.creditBalance;
            System.out.println("\n\tYour credit balance has been updated!");
	}
    }

    public void closeAccount(){
        this.creditAcctNo=0;
        this.creditBalance=0.0;
        System.out.println("\n\tYour credit account has been closed");
    }
     

    public boolean validateAcctNo(int acctNo){
        if(this.creditAcctNo==acctNo)
            return true;
        else
            return false;
    }
     
     
   
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package seatwork5simplecalculator;
import java.io.*;

/**
 *
 * @author jtfulgencio
 */
public class SimpleCalculator {

    /**
     * @param args the command line arguments
     */

    public static int add(int x,int y){
        int sum;
        sum=x+y;
        return sum;
    }
//******************************************************************************

    public static int subtract(int x,int y){
        return x-y;
    }
//******************************************************************************

    public static int multiply(int x,int y){
        x++;
        return x*y;
    }
//******************************************************************************

    public static double divide(int x,int y){
        return (double)x/y;
    }
//******************************************************************************

    public static void main(String[] args) throws Exception {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int x,y,diff;

        System.out.println("\nA SIMPLE C`       ALCULATOR PROGRAM\n");
        System.out.print("Enter the first number --> ");
        x=Integer.parseInt(br.readLine());
        System.out.print("Enter the second number --> ");
        y=Integer.parseInt(br.readLine());

        diff=subtract(x,y);

        System.out.println("Sum        = "+add(x,y));
        System.out.println("Difference = "+diff);
        System.out.println("x    = "+multiply(x,y));
        System.out.println("Quotient   = "+divide(x,y));

        System.out.println("x    = "+x);

    }

}



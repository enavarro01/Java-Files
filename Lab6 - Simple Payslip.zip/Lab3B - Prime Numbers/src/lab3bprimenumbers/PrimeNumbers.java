/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab3bprimenumbers;
import java.io.*;

/**
 *
 * @author Jho
 */
public class PrimeNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int choice,num1,num2,i,q=0;


        do{
        System.out.println("\n\n\n");
        System.out.println("\tMENU");
        System.out.println("[1] Prime or Composite");
        System.out.println("[2] All Prime Numbers");
        System.out.println("[3] Exit");
        System.out.print("    Enter your choice --> ");
        choice=Integer.parseInt(br.readLine());

        switch(choice){
            case 1: System.out.println("\n\n");
                    System.out.println("PRIME OR COMPOSITE");
                    System.out.print("Enter an integer --> ");
                    num1=Integer.parseInt(br.readLine());
                    for(i=2;i<num1;i++){
                       q=num1%i;
                       if(q==0) break;
                    }
                    if(num1==1 || num1==0)
                        System.out.println("Neither PRIME Nor COMPOSITE");
                    else if(q!=0 || num1==2 || num1==-1)
                        System.out.println(num1+" is a PRIME number");
                    else 
                        System.out.println(num1+" is a COMPOSITE number");
                    
                    
                    
                    break;

            case 2: System.out.println("\n\n");
                    System.out.println("ALL PRIME NUMBERS");



        }
        }while(choice!=3);
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab4anumberandcharactersortingver2;
import java.io.*;

/**
 *
 * @author Jho
 * @version July 2011
 */
public class NumAndCharSortVER2 {

    /**
     * @param args the command line arguments
     */

//******************************************************************************
    //sort the integers
    public static void sortIntegers(int[] intV){
        int i,pass=1,temp;

        while(pass<intV.length)
        {
            for(i=0;i<(intV.length-pass);i++)
            {
                if(intV[i]<intV[i+1])
                {
                    temp=intV[i];
                    intV[i]=intV[i+1];
                    intV[i+1]=temp;
                }
            }
            pass++;
        }
    }
//******************************************************************************

    //sort the characters
    public static void sortCharacters(char[] chrValues){
       int i,pass=1;
       char[] tempChar={' '};

        while(pass<chrValues.length)
        {
            for(i=0;i<(chrValues.length-pass);i++)
            {
                if(chrValues[i]<chrValues[i+1])
                {
                    tempChar[0]=chrValues[i];
                    chrValues[i]=chrValues[i+1];
                    chrValues[i+1]=tempChar[0];
                }
            }
            pass++;
        }
    }
//******************************************************************************

    //MAIN METHOD
    public static void main(String[] args) throws Exception {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int[] intValues=new int[5];
        char chrValues[],tempChar[]={' '},answer;
        String strValue;
        int i;

do{
        System.out.println("THIS PROGRAM USES USER-DEFINED METHODS TO SORT INTEGERS AND CHARACTERS");
        System.out.println();
        for(i=0;i<intValues.length;i++){
            System.out.print("Enter value for index["+i+"] here --> ");
            intValues[i]=Integer.parseInt(br.readLine());
        }
        System.out.println();
        System.out.print("Enter a string here --> ");
        strValue=br.readLine();

        //convert the string to chracter Array
        chrValues=strValue.toCharArray();

        sortIntegers(intValues);
        sortCharacters(chrValues);

        //display the sorted integers
        System.out.println();
        System.out.println("The integers after sorting are : ");
        for(i=0;i<intValues.length;i++)
        {
            System.out.println(intValues[i]);
        }

        //display the sorted characters
        System.out.println();
        System.out.println("The characters after sorting are : ");
        for(i=0;i<chrValues.length;i++)
        {
            System.out.println(chrValues[i]);
        }

        System.out.print("Continue? [y/n] --> ");
        answer=(char)System.in.read();
        System.in.read();

        for(i=1;i<25;i++){
            System.out.println();
        }

}while(answer=='y' || answer=='Y');
    }
}
//******************************************************************************


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabankphase1;
import java.io.*;

/**
 *
 * @author Jho
 */
public class Client {
//------------------------------------------------------------------------------

    public static int displayMenu() throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int transact;
        do{
        System.out.print("\n\n\n\t\t------JAVA BANK MAIN MENU------" +
                               "\n\t[1] New Account" +
                               "\n\t[2] Balance Inquiry" +
                               "\n\t[3] Deposit" +
                               "\n\t[4] Withdraw" +
                               "\n\t[5] Close Account" +
                               "\n\t[6] Exit" +
                               "\n\tPlease enter transaction code --> ");
        transact=Integer.parseInt(br.readLine());
        if(transact<1 || transact>6)
            System.out.println("\tINVALID CODE...Please try again!");
        }while(transact<1 || transact>6);

        return transact;
    }
//------------------------------------------------------------------------------

    public static void createNewAcct(BankAccount ba) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        double balance;  int acctNo;

        System.out.print("\n\n\n\t\t------NEW ACCOUNT------");
        System.out.print("\n\n\tEnter initial deposit --> ");
        balance=Double.parseDouble(br.readLine());
        if(balance<10000){
            System.out.print("\n\tMinimum initial deposit is Php 10,000");
        }
        else{
            ba.setBalance(balance);
            acctNo=999+(int)(Math.random()*10000);
            ba.setAcctNo(acctNo);
            System.out.println("\n\tYour account number is " + ba.getAcctNo());
        }
    }
//-------------------------THIS IS THE MAIN METHOD------------------------------

    public static void main(String[] args) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        BankAccount ba=new BankAccount();
        int trans,acctNo;
        double amount; char sure;

        do{
        trans=displayMenu();
        switch(trans){
            case 1: // New Account
                if(ba.getAcctNo()==0)
                    createNewAcct(ba);
                else
                    System.out.print("\n\tNOT AN ALLOWED TRANSACTION! ");
                break;

            case 2: //Balance Inquiry
                if(ba.getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------BALANCE INQUIRY------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(ba.validateAcctNo(acctNo))
                        ba.balanceInquiry();
                    else
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 3: //Deposit
                if(ba.getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------DEPOSIT TRANSACTION------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(ba.validateAcctNo(acctNo)){
                        System.out.print("\n\tEnter the amount to be deposited --> ");
                        amount=Double.parseDouble(br.readLine());
                        ba.deposit(amount);
                    }
                    else{
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 4:  //Withdraw
                if(ba.getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------WITHDRAW TRANSACTION------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(ba.validateAcctNo(acctNo)){
                        System.out.print("\n\tEnter the amount to be withdrawn --> ");
                        amount=Double.parseDouble(br.readLine());
                        ba.withdraw(amount);
                    }
                    else{
                    System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 5: //Close Account
                if(ba.getAcctNo()!=0){
                    System.out.print("\n\n\n\t\t------CLOSE ACCOUNT TRANSACTION------");
                    System.out.print("\n\n\tEnter your account number --> ");
                    acctNo=Integer.parseInt(br.readLine());
                    if(ba.validateAcctNo(acctNo)){
                        System.out.print("\n\tAre you sure to close your account? [y/n] --> ");
                        sure=(char)System.in.read();
                        System.in.read();
                        if(sure=='y' || sure=='Y'){
                            ba.closeAccount();
                        }
                    }
                    else{
                        System.out.println("\n\tINVALID ACCOUNT NUMBER!");
                    }
                }
                else{
                    System.out.println("\n\tPLEASE CREATE AN ACCOUNT FIRST!");
                }
                break;

            case 6: //Exit
                System.out.println("\n\tThank you for banking with us...");
        }
        }while(trans!=6);
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab5ajavazoopart1;

/**
 * Contains the main method.
 *
 * @author Jho Fulgencio
 * @version July 2011
 */
public class JavaZoo
{
    //attributes
    public static String zooName = "JAVA PARK N ZOO";

    //constructor
    public JavaZoo()
    {
        zooName="Java Park n Zoo";
    }

    //getters
    public static String getZooName()
    {
        return zooName;
    }

    //main method
    public static void main(String[] args)
    {
        ZooAnimal myFirstAnimal = new ZooAnimal();
        Cage myFirstCage = new Cage();
        ZooKeeper myFirstZooKeeper = new ZooKeeper();

        myFirstAnimal.setName("King");
        myFirstAnimal.setType("Lion");
        myFirstAnimal.setAge(10);

        System.out.println(getZooName());
        System.out.println("\nThe first animal I saw from this zoo is named "+ myFirstAnimal.getName());
        System.out.println("It is a "+ myFirstAnimal.getType());
        System.out.println("It is almost "+ myFirstAnimal.getAge() + " years of age");
        System.out.println("Is he hungry? "+ myFirstAnimal.isHungry());

        myFirstZooKeeper.setName("Mario d Baro");
        myFirstZooKeeper.setTitle("Mr.");
        

        System.out.println("\nI knew these because of a zoo keeper named "+myFirstZooKeeper.getTitle()+ " " +myFirstZooKeeper.getName() + " told me so");
        System.out.println("He used to earn $"+ myFirstZooKeeper.getPayRate()+ " per day");
        myFirstZooKeeper.setPayRate(100.00);
        System.out.println("But now he earns $"+ myFirstZooKeeper.getPayRate()+ " per day");
        System.out.println("Has he earned his degree yet? " + myFirstZooKeeper.hasDegree());

        myFirstCage.setLength(20);
        myFirstCage.setWidth(20);
        myFirstCage.setHeight(20);

        System.out.println("\nThe cage of " + myFirstAnimal.getName() + " has the following dimension: ");
        System.out.println("\t"+ myFirstCage.getLength()+ " X "+ myFirstCage.getWidth()+ " X "+ myFirstCage.getHeight()+ " meters");
        System.out.println("But, is the cage clean? "+ myFirstCage.isClean());
        myFirstCage.cleaned();
        System.out.println("Or is the cage covered? "+ myFirstCage.isCovered());
        
    }


    }


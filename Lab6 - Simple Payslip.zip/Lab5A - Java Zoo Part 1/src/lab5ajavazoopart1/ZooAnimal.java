/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab5ajavazoopart1;

/**
 * Lab activity in identifying the attributes and methods of ZooAnimal class.
 *
 * @author Jho Fulgencio
 * @version 10 August 2004
 */
public class ZooAnimal
{

	//attributes
	private String name;
	private String type;
	private int age;
	private boolean hungry;

	//constructor
	public ZooAnimal()
	{
	    this.name="";
	    this.type="";
	    this.age=0;
	    this.hungry=false;
	}

	//setters
	public void setName(String name)
	{
	    this.name=name;
	}

	public void setType(String type)
	{
	    this.type=type;
	}

	public void setAge(int age)
	{
	    this.age=age;
	}

	//getters
	public String getName()
	{
	    return this.name;
	}

	public String getType()
	{
	    return this.type;
	}

	public int getAge()
	{
	    return this.age;
	}

	public boolean isHungry()
	{
	    return this.hungry;
	}

}

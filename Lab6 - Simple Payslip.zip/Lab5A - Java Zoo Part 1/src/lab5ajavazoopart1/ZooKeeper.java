/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab5ajavazoopart1;

/**
 * Lab activity in identifying the attributes and methods of Cage class.
 *
 * @author Jho Fulgencio
 * @version July 2011
 */
public class ZooKeeper
{
	//attributes
	private String name;
	private String title;
	private double payRate;
	private boolean degree;

	//constructor
	public ZooKeeper()
	{
	    this.name="";
	    this.title="";
	    this.payRate=14.00;
	    this.degree=false;
	}

	//setters
	public void setName(String name)
	{
	    this.name = name;
	}

	public void setTitle(String title)
	{
	    this.title=title;
	}

	public void setPayRate(double payRate)
	{
	    this.payRate = payRate;
	}

	public void setDegree(boolean degree)
	{
	    this.degree = degree;
	}

	//getters
	public String getName()
	{
	    return this.name;
	}

	public String getTitle()
	{
	    return this.title;
	}

	public double getPayRate()
	{
	    return this.payRate;
	}

	public boolean hasDegree()
	{
	    return this.degree;
	}
}


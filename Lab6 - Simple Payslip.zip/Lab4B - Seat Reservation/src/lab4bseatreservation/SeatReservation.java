/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab4bseatreservation;
import java.io.*;

/**
 *
 * @author Jho
 */
public class SeatReservation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int i,j=0,seatValue=1,row=5,col=7;
        int[][] seats=new int[row][col];
        boolean again=true,vacant=false;        

        //populate the seats
        for(i=0;i<row;i++){
            for(j=0;j<col;j++){
                seats[i][j]=seatValue++;
            }
        }

        do{
        //display the board
        System.out.println("\n\n\t\t\tSEAT RESERVATION\n\t");
        for(i=0;i<row;i++){
            for(j=0;j<col;j++){
                System.out.print(seats[i][j] + "\t");
            }
            System.out.println();
        }

        System.out.print("\nPlease enter a seat number --> ");
        seatValue=Integer.parseInt(br.readLine());

        //validate seats
        if(seatValue<1 || seatValue>35){
            System.out.println("INVALID SEAT NUMBER!");
        }
        else{
            for(i=0;i<row;i++){
                for(j=0;j<col;j++){
                    if(seatValue==seats[i][j] && seats[i][j]!=0){
                        seats[i][j]=0;
                        vacant=false;
                        break;
                    }
                }
            }
            if(!vacant){
                vacant=true;
                System.out.println("Seat is successfully reserved!");
            }
            else{
                System.out.println("SEAT IS TAKEN!");
            }
        }
        }while(again);
    }

}

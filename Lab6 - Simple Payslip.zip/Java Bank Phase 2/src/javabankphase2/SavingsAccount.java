/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabankphase2;

/**
 *
 * @author Jho
 */
public class SavingsAccount extends BankAccount{
    private int acctNo;
    private double balance;
    private double interestRate;

    public SavingsAccount(){
        super();
        this.acctNo=0;
        this.balance=0.0;
        this.interestRate=0.05;
    }

    public int getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(int acctNo) {
        this.acctNo = acctNo;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public void deposit(double amount){
        double interest;

        if(amount<100){
            System.out.println("\n\tINVALID AMOUNT!");
        }
        else{
            this.balance+=amount;
            interest=this.balance*this.interestRate;
            this.balance+=interest;
            System.out.println("\n\tYour current balance has been updated");
        }
    }

    public void withdraw(double amount){
        if(amount<100){
            System.out.println("\n\tINVALID AMOUNT!");
        }
        else if(amount>this.balance){
            System.out.println("\n\tINSUFFICIENT FUND!");
        }
        else if(this.balance-amount < 10000){
            System.out.println("\n\tTHE MAINTAINING BALANCE IS Php 5,000.00!");
        }
        else{
            this.balance-=amount;
            System.out.println("\n\tYour current balance has been updated");
        }
    }
}

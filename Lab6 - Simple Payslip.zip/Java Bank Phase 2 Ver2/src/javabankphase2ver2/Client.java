/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javabankphase2ver2;

/**
 *
 * @author Jho
 */
public class Client {
    private String name;
    private String address;
    private String bday;
    private long contactNo;
    private SavingsAccount acct;

    public Client(){
        this.name="";
        this.address="";
        this.bday="";
        this.contactNo=0;
        this.acct=new SavingsAccount();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBday() {
        return bday;
    }

    public void setBday(String bday) {
        this.bday = bday;
    }

    public long getContactNo() {
        return contactNo;
    }

    public void setContactNo(long contactNo) {
        this.contactNo = contactNo;
    }

    public SavingsAccount getAcct() {
        return acct;
    }

    public void setAcct(SavingsAccount acct) {
        this.acct = acct;
    }

    //custom methods
    @Override
    public String toString(){
        String clientInfo = "\n\tClient Name : " + this.name +
                            "\n\tAddress     : " + this.address +
                            "\n\tBirthday    : " + this.bday +
                            "\n\tContact No. : " + this.contactNo;
        return clientInfo;
    }


}

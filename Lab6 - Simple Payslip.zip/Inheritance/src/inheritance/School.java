/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritance;

/**
 *
 * @author Jho
 */
public class School {
    private String schoolName;
    private Student stud;

    public School(){
        this.schoolName="My University";
        this.stud=new Student();
    }

    /**
     * @return the schoolName
     */
    public String getSchoolName() {
        return schoolName;
    }

    /**
     * @param schoolName the schoolName to set
     */
    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    /**
     * @return the stud
     */
    public Student getStud() {
        return stud;
    }

    /**
     * @param stud the stud to set
     */
    public void setStud(Student stud) {
        this.stud = stud;
    }

    

}

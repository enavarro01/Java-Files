/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritance;

/**
 *
 * @author Jho
 */
public class Person {
    private String name;
    private int age;

    public Person(){
        this.name="";
        this.age=0;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    public String eat(){
        return "Eating on the dining table...";
    }

    public double sendMoney(){
        return 123.45;
    }

}

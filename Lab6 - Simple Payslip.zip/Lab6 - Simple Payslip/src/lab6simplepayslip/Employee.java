/*
 * To change this template, choose Tools | Templatsp
 * and open the template in the editor.
 */

package lab6simplepayslip;
import java.io.*;
import java.text.*;

/**
 *
 * @author jtfulgencio
 */
public class Employee {

    /**
     * @param args the command line arguments
     */

    public static void acceptObject(SimplePayslip sp){
        System.out.println("\n\n\nDisplaying from the acceptObject method:");
        System.out.println("\tNet Pay        : Php "+sp.getNetPay());
        sp.setNetPay(10000);
        System.out.println("\tNet Pay        : Php "+sp.getNetPay());

    }


    public static void main(String[] args) throws Exception {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        DecimalFormat df=new DecimalFormat("#,##0.00");
        SimplePayslip sp=new SimplePayslip();

        int empNo;
        String empName,position;
        char payGrade;
        double basic,otHrs,taxRate,grossPay,netPay,withTax,sss=500,love=100,philH=200;

        System.out.print("\nEnter employee number --> ");
        empNo=Integer.parseInt(br.readLine());
        System.out.print("Enter employee name   --> ");
        empName=br.readLine();
        System.out.print("Enter basic salary    --> ");
        basic=Double.parseDouble(br.readLine());
        System.out.print("Enter no. of OT hours --> ");
        otHrs=Double.parseDouble(br.readLine());

        sp.setEmpNo(empNo);
        sp.setEmpName(empName);
        sp.setBasic(basic);
        sp.setOtHrs(otHrs);

        sp.computeGrossPay();
        taxRate=sp.determineValues();
        sp.computeWithTax(taxRate);
        sp.computeOtherDeduct(sss, love, philH);
        sp.computeNetPay();

        //this is the display
        System.out.println("\n\n\nSUMMARY SIMPLE PAY SLIP");
        System.out.println("\n\tEmployee No.   : "+sp.getEmpNo());
        System.out.println("\tEmployee Name  : "+sp.getEmpName());
        System.out.println("\tPosition       : "+sp.getPosition());
        System.out.println("\tPay Grade      : "+sp.getPayGrade());
        System.out.println("\tNo. of OT Hours: "+sp.getOtHrs());
        System.out.println("\tBasic Salary   : Php "+df.format(sp.getBasic()));
        System.out.println("\tGross Pay      : Php "+df.format(sp.getGrossPay()));
        System.out.println("\tDeductions     : ");
        System.out.println("\t\tWithholding Tax = "+df.format(sp.getWithTax()));
        System.out.println("\t\tSSS             = "+df.format(sss));
        System.out.println("\t\tPag-ibig        = "+df.format(love));
        System.out.println("\t\tPhilhealth      = "+df.format(philH));
        System.out.println("\tNet Pay        : Php "+df.format(sp.getNetPay()));

        acceptObject(sp);
        System.out.println("\n\n\nDisplaying from the main method again:");
        System.out.println("\tNet Pay        : Php "+sp.getNetPay());


    }

}

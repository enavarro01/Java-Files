/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lab6simplepayslip;

/**
 *
 * @author jtfulgencio
 */
public class SimplePayslip {
    private int empNo;
    private String empName;
    private String position;
    private char payGrade;
    private double basic;
    private double otHrs;
    private double grossPay;
    private double netPay;
    private double withTax;
    private double otherDeduct;

    /**
     * @return the empNo
     */
    public int getEmpNo() {
        return empNo;
    }

    /**
     * @param empNo the empNo to set
     */
    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    /**
     * @return the empName
     */
    public String getEmpName() {
        return empName;
    }

    /**
     * @param empName the empName to set
     */
    public void setEmpName(String empName) {
        this.empName = empName;
    }

    /**
     * @return the position
     */
    public String getPosition() {
        return position;
    }

    /**
     * @param position the position to set
     */
    public void setPosition(String position) {
        this.position = position;
    }

    /**
     * @return the payGrade
     */
    public char getPayGrade() {
        return payGrade;
    }

    /**
     * @param payGrade the payGrade to set
     */
    public void setPayGrade(char payGrade) {
        this.payGrade = payGrade;
    }

    /**
     * @return the basic
     */
    public double getBasic() {
        return basic;
    }

    /**
     * @param basic the basic to set
     */
    public void setBasic(double basic) {
        this.basic = basic;
    }

    /**
     * @return the otHrs
     */
    public double getOtHrs() {
        return otHrs;
    }

    /**
     * @param otHrs the otHrs to set
     */
    public void setOtHrs(double otHrs) {
        this.otHrs = otHrs;
    }

    /**
     * @return the grossPay
     */
    public double getGrossPay() {
        return grossPay;
    }

    /**
     * @param grossPay the grossPay to set
     */
    public void setGrossPay(double grossPay) {
        this.grossPay = grossPay;
    }

    /**
     * @return the netPay
     */
    public double getNetPay() {
        return netPay;
    }

    /**
     * @param netPay the netPay to set
     */
    public void setNetPay(double netPay) {
        this.netPay = netPay;
    }

    /**
     * @return the withTax
     */
    public double getWithTax() {
        return withTax;
    }

    /**
     * @param withTax the withTax to set
     */
    public void setWithTax(double withTax) {
        this.withTax = withTax;
    }

    /**
     * @return the otherDeduct
     */
    public double getOtherDeduct() {
        return otherDeduct;
    }

    /**
     * @param otherDeduct the otherDeduct to set
     */
    public void setOtherDeduct(double otherDeduct) {
        this.otherDeduct = otherDeduct;
    }

    //custom methods
    public void computeGrossPay(){
        this.grossPay=(this.otHrs*0.01*this.basic) + this.basic;
    }
    public double determineValues(){
        double taxRate=0.0;

        if(this.basic>=8000 && this.basic<10000){
            this.position="Technician";
            this.payGrade='A';
            taxRate=0.10;
        }
        else if(this.basic >= 10000 && this.basic < 12000)
        {
            this.position="Technician";
            this.payGrade='B';
            taxRate=0.10;
        }
        else if(this.basic >= 12000 && this.basic < 15000)
        {
            this.position="Encoder";
            this.payGrade='A';
            taxRate=0.12;
        }
        else if(this.basic >= 15000 && this.basic < 18000)
        {
            this.position="Encoder";
            this.payGrade='B';
            taxRate=0.12;
        }
        else if(this.basic >= 18000 && this.basic < 20000)
        {
            this.position="Programmer";
            this.payGrade='A';
            taxRate=0.15;
        }
        else if(this.basic >= 20000 && this.basic < 25000)
        {
            this.position="Programmer";
            this.payGrade='B';
            taxRate=0.15;
        }
        else if(this.basic >= 25000 && this.basic < 30000)
        {
            this.position="Systems Analyst";
            this.payGrade='A';
            taxRate=0.18;
        }
        else if(this.basic >= 30000 && this.basic < 40000)
        {
            this.position="Systems Analyst";
            this.payGrade='B';
            taxRate=0.18;
        }
        else if(this.basic >= 40000 && this.basic < 60000)
        {
            this.position="Manager";
            this.payGrade='A';
            taxRate=0.2;
        }
        else if(this.basic >= 60000)
        {
            this.position="Manager";
            this.payGrade='B';
            taxRate=0.2;
        }

        return taxRate;
    }

    public void computeWithTax(double taxRate){
        this.withTax=taxRate*this.grossPay;
    }

    public void computeNetPay(){
        this.netPay=this.grossPay-this.withTax-this.otherDeduct;
    }

    public void computeOtherDeduct(double sss,double love, double philH){
        this.otherDeduct=sss+love+philH;
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sampleenrollmentslip;

/**
 *
 * @author jtfulgencio
 */
public class EnrollmentSlip {
    private int studNo;
    private String studName;
    private String course;
    private int year;
    private double units;
    private double tuition;
    private double balance;

    public EnrollmentSlip(){
        this.studNo=0;
        this.studName="";
        this.course="";
        this.year=0;
        this.units=0.0;
        this.tuition=0.0;
        this.balance=0.0;
    }

    /**
     * @return the studNo
     */
    public int getStudNo() {
        return studNo;
    }

    /**
     * @param studNo the studNo to set
     */
    public void setStudNo(int studNo) {
        this.studNo = studNo;
    }

    /**
     * @return the studName
     */
    public String getStudName() {
        return studName;
    }

    /**
     * @param studName the studName to set
     */
    public void setStudName(String studName) {
        this.studName = studName;
    }

    /**
     * @return the course
     */
    public String getCourse() {
        return course;
    }

    /**
     * @param course the course to set
     */
    public void setCourse(String course) {
        this.course = course;
    }

    /**
     * @return the year
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * @return the units
     */
    public double getUnits() {
        return units;
    }

    /**
     * @param units the units to set
     */
    public void setUnits(double units) {
        this.units = units;
    }

    /**
     * @return the tuition
     */
    public double getTuition() {
        return tuition;
    }

    /**
     * @param tuition the tuition to set
     */
    public void setTuition(double tuition) {
        this.tuition = tuition;
    }

    /**
     * @return the balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * @param balance the balance to set
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    


}
